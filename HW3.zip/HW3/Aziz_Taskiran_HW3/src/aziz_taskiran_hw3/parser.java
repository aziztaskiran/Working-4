package aziz_taskiran_hw3;
/**
 *
 * @author aziz
 */
import java.util.Stack;

public class parser implements ParserInterface
{
    private Stack myStack=new Stack();
    private Stack basamak=new Stack();
    private Stack son=new Stack();
    
    @Override
    public int isValid(String myInput) 
    {
        int t=1,i,say1=0,say2=0,k,m=0,number=0,operator=0;
        float x,y,z,a,b,c;
        for(i=0;i<myInput.length();i++)
        {
            if(myInput.charAt(i)=='(')
            {
                say1++;
            }
            if(myInput.charAt(i)==')')
            {
                say2++;
            }
        }
        if(say1!=say2)
        {
            System.out.println("Parenthesis Error"); 
            return 2;
        }
        for(k=0;k<myInput.length();k++)
        {
            if(myInput.charAt(k)!='(' && myInput.charAt(k)!=')' && myInput.charAt(k)!='^' && myInput.charAt(k)!='*' && myInput.charAt(k)!='/' && myInput.charAt(k)!='+' && myInput.charAt(k)!='-' && myInput.charAt(k)!=' ' && myInput.charAt(k)!='.')
            {
                if(myInput.charAt(k)!='0' && myInput.charAt(k)!='1' && myInput.charAt(k)!='2' && myInput.charAt(k)!='3' && myInput.charAt(k)!='4' && myInput.charAt(k)!='5' && myInput.charAt(k)!='6' && myInput.charAt(k)!='7' && myInput.charAt(k)!='8' && myInput.charAt(k)!='9')
                {
                    System.out.println("Unexpected Character Error");
                    return 4;
                }
            }
        }
        for(k=0;k<myInput.length();k++)
        {
            if(myInput.charAt(k)!='(' && myInput.charAt(k)!=')' && myInput.charAt(k)!='^' && myInput.charAt(k)!='*' && myInput.charAt(k)!='/' && myInput.charAt(k)!='+' && myInput.charAt(k)!='-' && myInput.charAt(k)!='.')
            {
                if(myInput.charAt(k)!='0' && myInput.charAt(k)!='1' && myInput.charAt(k)!='2' && myInput.charAt(k)!='3' && myInput.charAt(k)!='4' && myInput.charAt(k)!='5' && myInput.charAt(k)!='6' && myInput.charAt(k)!='7' && myInput.charAt(k)!='8' && myInput.charAt(k)!='9')
                {
                    m++;
                }
            }
        }
        if(m==myInput.length())
        {
            System.out.println("Empty String Error");
            return 6;
        }
        for(k=0;k<myInput.length();k++)
        {
            if(myInput.charAt(k)=='.')
            {
               System.out.println("Unexpected Float Error");
               return 5; 
            }
        }
        for(k=0;k<myInput.length();k++)
        {
            if(myInput.charAt(k)=='^' || myInput.charAt(k)=='*' || myInput.charAt(k)=='/' || myInput.charAt(k)=='+' || myInput.charAt(k)=='-')
            {
                operator++;
            }
        }
        for(k=0;k<myInput.length();k++)
        {
            if(myInput.charAt(k)=='0' || myInput.charAt(k)=='1' || myInput.charAt(k)=='2' || myInput.charAt(k)=='3' || myInput.charAt(k)=='4' || myInput.charAt(k)=='5' || myInput.charAt(k)=='6' || myInput.charAt(k)=='7' || myInput.charAt(k)=='8' || myInput.charAt(k)=='9')
            {
                while((k<(myInput.length()-1)) && (myInput.charAt(k+1)=='0' || myInput.charAt(k+1)=='1' || myInput.charAt(k+1)=='2' || myInput.charAt(k+1)=='3' || myInput.charAt(k+1)=='4' || myInput.charAt(k+1)=='5' || myInput.charAt(k+1)=='6' || myInput.charAt(k+1)=='7' || myInput.charAt(k+1)=='8' || myInput.charAt(k+1)=='9'))
                {
                    k++;
                }
                number++;
            }
        }
        if(number!=(operator+1))
        {
            System.out.println("Missing Operator");
            return 3;
        }
        
        String BoslukSil=myInput.replaceAll(" ", "");
        
        for(k=0;k<(BoslukSil.length()-1);k++)
        {
            if(BoslukSil.charAt(k)==')' && BoslukSil.charAt(k+1)=='(')
            {
                System.out.println("Missing Operator");
                return 3;
            }
        }
        for(k=0;k<(BoslukSil.length()-1);k++)
        {
            if(BoslukSil.charAt(k)==')' && (BoslukSil.charAt(k+1)=='0' || BoslukSil.charAt(k+1)=='1' || BoslukSil.charAt(k+1)=='2' || BoslukSil.charAt(k+1)=='3' || BoslukSil.charAt(k+1)=='4' || BoslukSil.charAt(k+1)=='5' || BoslukSil.charAt(k+1)=='6' || BoslukSil.charAt(k+1)=='7' || BoslukSil.charAt(k+1)=='8' || BoslukSil.charAt(k+1)=='9'))
            {
                System.out.println("Missing Operator");
                return 3;
            }
        }
        for(k=0;k<(BoslukSil.length()-1);k++)
        {
            if(BoslukSil.charAt(k+1)==')' && (BoslukSil.charAt(k)=='^' || BoslukSil.charAt(k)=='*' || BoslukSil.charAt(k)=='/' || BoslukSil.charAt(k)=='+' || BoslukSil.charAt(k)=='-'))
            {
                System.out.println("Missing Operator");
                return 3;
            }
        }
        for(k=0;k<(BoslukSil.length()-1);k++)
        {
            if(BoslukSil.charAt(k+1)=='(' && (BoslukSil.charAt(k)=='0' || BoslukSil.charAt(k)=='1' || BoslukSil.charAt(k)=='2' || BoslukSil.charAt(k)=='3' || BoslukSil.charAt(k)=='4' || BoslukSil.charAt(k)=='5' || BoslukSil.charAt(k)=='6' || BoslukSil.charAt(k)=='7' || BoslukSil.charAt(k)=='8' || BoslukSil.charAt(k)=='9')) 
            {
                System.out.println("Missing Operator");
                return 3;
            }
        }
        for(k=0;k<(BoslukSil.length()-1);k++)
        {
            if(BoslukSil.charAt(k)=='(' && (BoslukSil.charAt(k+1)=='^' || BoslukSil.charAt(k+1)=='*' || BoslukSil.charAt(k+1)=='/' || BoslukSil.charAt(k+1)=='+' || BoslukSil.charAt(k+1)=='-'))
            {
                System.out.println("Missing Operator");
                return 3;
            }
        }
        for(k=0;k<(BoslukSil.length()-1);k++)
        {
            if(BoslukSil.charAt(k)=='^' || BoslukSil.charAt(k)=='*' || BoslukSil.charAt(k)=='/' || BoslukSil.charAt(k)=='+' || BoslukSil.charAt(k)=='-')
            {
                if(BoslukSil.charAt(k+1)=='^' || BoslukSil.charAt(k+1)=='*' || BoslukSil.charAt(k+1)=='/' || BoslukSil.charAt(k+1)=='+' || BoslukSil.charAt(k+1)=='-')
                {
                    System.out.println("Missing Operator");
                    return 3;
                }
            }
        }
        for(k=0;k<(myInput.length()-1);k++)
        {
            if(myInput.charAt(k)=='0' || myInput.charAt(k)=='1' || myInput.charAt(k)=='2' || myInput.charAt(k)=='3' || myInput.charAt(k)=='4' || myInput.charAt(k)=='5' || myInput.charAt(k)=='6' || myInput.charAt(k)=='7' || myInput.charAt(k)=='8' || myInput.charAt(k)=='9')
            {
                if((k+t)<myInput.length()&&(myInput.charAt(k+t)==' '))
                {
                    while((k+t)<myInput.length()&&(myInput.charAt(k+t)==' '))
                    {
                        t++;
                    }
                    if(((k+t)<myInput.length()) && (myInput.charAt(k+t)=='0' || myInput.charAt(k+t)=='1' || myInput.charAt(k+t)=='2' || myInput.charAt(k+t)=='3' || myInput.charAt(k+t)=='4' || myInput.charAt(k+t)=='5' || myInput.charAt(k+t)=='6' || myInput.charAt(k+t)=='7' || myInput.charAt(k+t)=='8' || myInput.charAt(k+t)=='9'))
                    {
                        System.out.println("Missing Operator");
                        return 3;
                    } 
                }
                t=1;
            }
        }
        x=7;
        y=0;
        z=x/y;
        a=-7;
        b=0;
        c=a/b;
        if(z==evaluate(myInput) || c==evaluate(myInput))
        {
            System.out.println("Division by Zero");
            return 1; 
        }
        return 0;
    }

    @Override
    public Float evaluate(String myInput) 
    {
        char a,b,c,d,f,g;
        int i,j,k,m,sayac,n,sayac2;
        float sonuc,x,y,z,birles;
        String postfix= "";
        String strBas= "";
        
        for(i=0;i<myInput.length();i++)
        {
            if(myInput.charAt(i)=='(')
            {
                myStack.push(myInput.charAt(i));
            }
            else if(myInput.charAt(i)=='^' || myInput.charAt(i)=='*' || myInput.charAt(i)=='/' || myInput.charAt(i)=='+' || myInput.charAt(i)=='-')
            {
                while(!myStack.isEmpty())
                {
                    a = (char) myStack.peek();
                    if(a=='(')
                    {
                        myStack.push(myInput.charAt(i));
                        break;
                    }
                    if( a=='+' || a=='-')
                    {
                        myStack.push(myInput.charAt(i));
                        break;
                    }
                    if(a=='^')
                    {
                       c=(char)myStack.peek();
                       myStack.pop();
                       postfix += c;
                       myStack.push(myInput.charAt(i));
                       break;
                    }
                    if(a=='*'||a=='/')
                    {
                        if(myInput.charAt(i)=='+'|| myInput.charAt(i)=='-' || myInput.charAt(i)=='*' || myInput.charAt(i)=='/')
                        {
                            d=(char)myStack.peek();
                            myStack.pop();
                            postfix += d;
                            myStack.push(myInput.charAt(i));
                            break;
                        }
                        if(myInput.charAt(i)=='^')
                        {
                            myStack.push(myInput.charAt(i));
                            break;
                        }
                    }
                }
                if(myStack.isEmpty())
                {
                    myStack.push(myInput.charAt(i));
                }
            }
            else if(myInput.charAt(i)==')')
            {
                while((char)myStack.peek()!='(')
                {
                    b=(char)myStack.peek();
                    myStack.pop();
                    postfix += b;
                }
                myStack.pop();
            }
            else if(myInput.charAt(i)!= ' ')
            {
                sayac=0;
                for(k=i;k<myInput.length();k++)
                {
                    if(myInput.charAt(k)!='(' && myInput.charAt(k)!=')' && myInput.charAt(k)!='^' && myInput.charAt(k)!='*' && myInput.charAt(k)!='/' && myInput.charAt(k)!='+' && myInput.charAt(k)!='-' && myInput.charAt(k)!=' ')
                    {
                        basamak.push(myInput.charAt(k));
                        sayac++;
                    }
                    else
                    {
                        break;
                    }
                }
                if(sayac>1)
                {
                    for(m=0;m<sayac;m++)
                    {
                       son.push(basamak.pop());
                    }
                    for(m=0;m<sayac;m++)
                    {
                       strBas+=son.pop();
                    }
                    postfix+=' ';
                    postfix+=strBas;
                    postfix+=' ';
                    strBas="";
                }
                else
                {
                    basamak.pop();
                    f=(char)myInput.charAt(i);
                    postfix +=f;
                }
                i+=(sayac-1);
            }
        }
        while(!myStack.isEmpty())
        {
            g=(char)myStack.peek();
            myStack.pop();
            postfix += g;
        }
        for(j=0;j<postfix.length();j++)
        {
            if(postfix.charAt(j)!=' ' && postfix.charAt(j)!='^' && postfix.charAt(j)!='*' && postfix.charAt(j)!='/' && postfix.charAt(j)!='+' && postfix.charAt(j)!='-')
            {
                myStack.push((float)postfix.charAt(j)-'0');
            }
            if(postfix.charAt(j)==' ')
            {
                sayac2=0;
                for(n=(j+1);n<postfix.length();n++)
                {
                    sayac2++;
                    if(postfix.charAt(n)!= ' ')
                    {
                        strBas+=postfix.charAt(n);
                    }
                    else
                    {
                        break;
                    }
                }
                birles=Float.parseFloat(strBas);
                strBas="";
                myStack.push(birles);
                j+=sayac2;
            }
            if(postfix.charAt(j)=='^')
            {
                x = (float)myStack.pop();
                y = (float)myStack.pop();
                z = (float)Math.pow(y,x);
                myStack.push(z);
            }
            if(postfix.charAt(j)=='*')
            {
                x = (float)myStack.pop();
                y = (float)myStack.pop();
                z = y*x;
                myStack.push(z);
            }
            if(postfix.charAt(j)=='/')
            {
                x = (float)myStack.pop();
                y = (float)myStack.pop();
                z = y/x;
                myStack.push(z);
            }
            if(postfix.charAt(j)=='+')
            {
                x = (float)myStack.pop();
                y = (float)myStack.pop();
                z = y+x;
                myStack.push(z);
            }
            if(postfix.charAt(j)=='-')
            {
                x = (float)myStack.pop();
                y = (float)myStack.pop();
                z = y-x;
                myStack.push(z);
            }
        }
        sonuc=(float)myStack.pop();
        return sonuc;
    }
}   
    
    
    


