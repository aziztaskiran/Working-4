
package aziz_taskiran_hw3;

/**
 *
 * @author aziz
 */
public interface ParserInterface 
{
    public int isValid(String myInput); 
    // 0 valid expression
    // 1 division by zero error
    // 2 parantheses mismatch error
    // 3 missing operator error
    // 4 unexpexted character
    // 5 unexpected float error
    // 6 empty string error
    public Float evaluate(String myInput);
    
}


