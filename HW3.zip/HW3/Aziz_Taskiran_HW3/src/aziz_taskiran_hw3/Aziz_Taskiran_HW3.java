package aziz_taskiran_hw3;

/**
 *
 * @author aziz
 */
public class Aziz_Taskiran_HW3 
{
     /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        String myST = "(+ 5000/100  44)";
        parser Myparser = new parser();
        if (Myparser.isValid(myST) == 0)
        System.out.println("The result : " + Myparser.evaluate(myST) );
        
    }
    
}
